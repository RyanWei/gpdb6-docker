# docs-greenplum-db 
Documentation for Greenplum Database

# Note: docs-gpdb master as of 253a88550e89355d78581b03f6ccc86b81d02cc4
